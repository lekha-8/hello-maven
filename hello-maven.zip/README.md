# Hello Maven

A simple Java project to demonstrate Maven structure.

## Run the application

Make sure you have Maven installed. Then run:

```bash
mvn compile
mvn exec:java
```

Expected Output:

```
Hello, Maven!
```
